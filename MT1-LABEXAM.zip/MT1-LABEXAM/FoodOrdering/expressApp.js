import express from 'express';

const app = express();
const PORT = 4000;

app.use(express.json());

let foods = [
  { id: 1, foodName: 'Pizza', category: 'Fast Food', price: 250, availability: true },
  { id: 2, foodName: 'Burger', category: 'Fast Food', price: 120, availability: true },
  { id: 3, foodName: 'Pasta', category: 'Italian', price: 180, availability: false }
];

const REQUIRED_FIELDS = ['id', 'foodName', 'category', 'price', 'availability'];

const isPositiveNumber = (value) => typeof value === 'number' && value > 0;

// GET all foods
app.get('/foods', (req, res) => {
  res.json(foods);
});

// GET food by id
app.get('/foods/:id', (req, res) => {
  const id = Number(req.params.id);
  const food = foods.find((item) => item.id === id);

  if (!food) {
    return res.status(404).json({ error: 'Food item not found' });
  }
  res.json(food);
});

// POST add new food
app.post('/foods', (req, res) => {
  const newFood = req.body || {};

  const missingFields = REQUIRED_FIELDS.filter(
    (field) => newFood[field] === undefined || newFood[field] === null || newFood[field] === ''
  );

  if (missingFields.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', missingFields });
  }

  if (!isPositiveNumber(newFood.price)) {
    return res.status(400).json({ error: 'Price must be a positive number' });
  }

  if (foods.some((item) => item.id === newFood.id)) {
    return res.status(400).json({ error: 'Food item with this id already exists' });
  }

  foods.push(newFood);
  res.status(201).json({ message: 'Food item added successfully', food: newFood });
});

// PUT update food
app.put('/foods/:id', (req, res) => {
  const id = Number(req.params.id);
  const food = foods.find((item) => item.id === id);

  if (!food) {
    return res.status(404).json({ error: 'Food item not found' });
  }

  const { foodName, category, price, availability } = req.body || {};

  if (price !== undefined && !isPositiveNumber(price)) {
    return res.status(400).json({ error: 'Price must be a positive number' });
  }

  if (foodName !== undefined) food.foodName = foodName;
  if (category !== undefined) food.category = category;
  if (price !== undefined) food.price = price;
  if (availability !== undefined) food.availability = availability;

  res.json({ message: 'Food item updated successfully', food });
});

// DELETE food
app.delete('/foods/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = foods.findIndex((item) => item.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Food item not found' });
  }

  const [deletedFood] = foods.splice(index, 1);
  res.json({ message: 'Food item deleted successfully', food: deletedFood });
});

// Invalid JSON body handler
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400) {
    return res.status(400).json({ error: 'Invalid JSON format' });
  }
  next(err);
});

// Invalid routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(PORT, () => {
  console.log(`Express Server running at http://localhost:${PORT}`);
});
