import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3000;

// In-memory food records (no database)
const foods = [
  { id: 1, foodName: 'Pizza', category: 'Fast Food', price: 250, availability: true },
  { id: 2, foodName: 'Burger', category: 'Fast Food', price: 120, availability: true },
  { id: 3, foodName: 'Pasta', category: 'Italian', price: 180, availability: false }
];

const REQUIRED_FIELDS = ['id', 'foodName', 'category', 'price', 'availability'];

const sendJSON = (res, statusCode, data) => {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data, null, 2));
};

const sendHTML = (res, statusCode, html) => {
  res.writeHead(statusCode, { 'Content-Type': 'text/html' });
  res.end(html);
};

const server = http.createServer((req, res) => {
  const { pathname } = new URL(req.url, `http://${req.headers.host}`);
  const method = req.method;

  // A2: Home page
  if (pathname === '/' && method === 'GET') {
    sendHTML(
      res,
      200,
      `<h1>Welcome to Tasty Bites Restaurant</h1>
       <p>Order your favourite food online!</p>
       <ul>
         <li><a href="/foods">Available Foods</a></li>
         <li><a href="/about">About Us</a></li>
         <li><a href="/menu">Menu</a></li>
       </ul>`
    );

  // A3: GET /foods -> only available items
  } else if (pathname === '/foods' && method === 'GET') {
    const availableFoods = foods.filter((food) => food.availability === true);
    sendJSON(res, 200, availableFoods);

  // A2: About page
  } else if (pathname === '/about' && method === 'GET') {
    sendHTML(
      res,
      200,
      `<h1>About Tasty Bites</h1>
       <p>Established in 2020, we serve fresh and tasty food.</p>
       <p>Timings: 10:00 AM - 11:00 PM</p>
       <p>Location: Ghaziabad, Uttar Pradesh</p>`
    );

  // A4: Static file serving using fs
  } else if (pathname === '/menu' && method === 'GET') {
    const filePath = path.join(__dirname, 'public', 'menu.html');
    fs.readFile(filePath, (err, data) => {
      if (err) {
        sendJSON(res, 500, { error: 'Internal Server Error: Unable to read menu file' });
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });

  // A3: POST /add-food
  } else if (pathname === '/add-food' && method === 'POST') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk.toString();
    });

    req.on('end', () => {
      let newFood;

      try {
        newFood = JSON.parse(body);
      } catch (error) {
        sendJSON(res, 400, { error: 'Invalid JSON format' });
        return;
      }

      if (newFood === null || typeof newFood !== 'object' || Array.isArray(newFood)) {
        sendJSON(res, 400, { error: 'Request body must be a JSON object' });
        return;
      }

      const missingFields = REQUIRED_FIELDS.filter(
        (field) => newFood[field] === undefined || newFood[field] === null || newFood[field] === ''
      );

      if (missingFields.length > 0) {
        sendJSON(res, 400, { error: 'Missing required fields', missingFields });
        return;
      }

      foods.push(newFood);
      sendJSON(res, 201, { message: 'Food item added successfully', food: newFood });
    });

  // A5: Invalid route
  } else {
    sendJSON(res, 404, { error: 'Route not found' });
  }
});

server.listen(PORT, () => {
  console.log(`HTTP Server running at http://localhost:${PORT}`);
});
