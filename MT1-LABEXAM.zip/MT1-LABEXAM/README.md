# MT1-LABEXAM - Online Food Ordering

Node.js HTTP module (Part A, port 3000) and Express.js REST API (Part B, port 4000).

```bash
cd FoodOrdering
npm install
node httpServer.js     # http://localhost:3000
node expressApp.js     # http://localhost:4000
```
